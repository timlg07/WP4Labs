  <?php get_header(); ?>
  <div id="contentbody" class="clearfix">
		<div id="sidebar">
		<?php get_sidebar(); ?>
		</div>
		<div id="content" class="padding">
		<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div id="post-<?php the_ID(); ?>" class="project">
				<?php echo_project_members($post->ID); ?>
				
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</div>
		<?php endwhile; // end of the lop ?>

	</div>

<?php get_footer(); ?>
