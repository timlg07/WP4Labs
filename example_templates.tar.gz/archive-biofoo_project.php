  <?php get_header(); ?>
  <div id="contentbody" class="clearfix">
		<div id="sidebar">
		<?php get_sidebar(); ?>
		</div>
		</div>
		<div id="content" class="padding">
		<?php  $posts = query_posts( $query_string . '&orderby=post_modified&order=asc' ); /* damit die zu letzt bearbeiteten projekte oben kommen */ ?>
		<?php if (have_posts()) : ?>
	                <?php while (have_posts()) : the_post(); ?>
		                <?php if (get_project_option($post->ID) != 'lonely_single') : ?> 
			                <div class="post">
			                	<h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
						<div id="meta"><?php echo_project_members($post->ID, 'text', true); ?></div>
						<?php the_excerpt(); ?>
			                </div>
				<?php endif; ?>
	                <?php endwhile; ?>
                <?php else: ?>
			<p><?php _e('No Projects set up yet!'); ?></p>
            	<?php endif; ?>
	</div>
<?php get_footer(); ?>



