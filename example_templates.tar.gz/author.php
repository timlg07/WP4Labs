<?php get_header(); ?>
<div id="sidebar">
	<?php get_sidebar(); ?>
</div>
<div id="content" role="main">
	<?php
		$user_id = (int) $_GET['author']; 
		// echo get_author_posts_url(get_the_author_meta('ID'))
		$user = get_biofoo(get_userdata($user_id));
		if (is_object($user)) :
	?>
	<div id='userpage'>
	<div id='userpage_head'>
		<div id='userpage_avatar'><?php echo get_avatar($user->ID); ?></div>
		<h2 class="page-title author"><?php echo esc_attr($user->first_name . ' ' . $user->last_name) ?><?php $user->first_name . ' ' . $user->last_name ?></h2>
		<h3 class="<?php echo esc_attr($user->group); echo ($user->active_group) ? 'active' : 'passive';?>"><?php echo $user->group; ?></h3>
	</div>
	
	<h4><?php echo _e('Contact Info'); ?></h4>
	<table class="user_info">
		<tr><td>Email</td><td><?php echo $user->nice_email; ?></td></tr>
		<?php if ($user->tel_nr) : ?><tr><td>Tel.</td><td><?php echo $user->tel_nr; ?></td><tr><?php endif; ?>	
		<?php if ($user->aim) : ?><tr><td>AOL instant Messanger</td><td><?php echo $user->aim; ?></td><tr><?php endif; ?>
		<?php if ($user->yim) : ?><tr><td>Yahoo instant Messanger</td><td><?php echo $user->yim; ?></td><tr><?php endif; ?>
		<?php if ($user->jabber) : ?><tr><td>AOL instant Messanger</td><td><?php echo $user->jabber; ?></td><tr><?php endif; ?>
		<?php if ($user->user_url) : ?><tr><td>Homepage</td><td><a href="<?php echo $user->user_url; ?>"><?php echo $user->user_url; ?></a></td><tr><?php endif; ?>
		<?php if ($user->blog_rss) : ?><tr><td>Blog</td><td><a href="<?php echo $user->blog_rss; ?>"><?php echo $user->blog_rss; ?></a></td><tr><?php endif; ?>
	</table>
	
	<?php if (($user->ba_degree or $user->ma_degree) or $user->phd_degree) : ?>
		<h4><?php echo _e('Academic Degrees'); ?></h4>
		<table class="user_info">
			<?php if ($user->ba_degree) : ?><tr><td>B.A.</td><td><?php echo $user->ba_degree; ?></td></tr><?php endif; ?>
			<?php if ($user->ma_degree) : ?><tr><td>M.A.</td><td><?php echo $user->ma_degree; ?></td></tr><?php endif; ?>
			<?php if ($user->phd_degree) : ?><tr><td>Ph.D.</td><td><?php echo $user->phd_degree; ?></td></tr><?php endif; ?>
		</table>
	<?php endif; ?>
	
	<?php if ($user->inst_name) : ?>
		<h4><?php echo _e('Scientific Institution'); ?></h4>
		<p><a href="<?php echo $user->inst_url; ?>" target='_blank'><?php echo $user->inst_name; ?></a><br /><?php echo $user->inst_dep; ?></p>
	<?php endif; ?>
	
	<?php if ($user->description) : ?>
		<h4><?php echo _e('Biographical Information'); ?></h4>
		<p id='user-description'><?php echo $user->description; ?></p>
	<?php endif; ?>
	
	
	<h4>Projects</h4>
	<?php list_users_projects($user->ID); ?>
	
	<h4><?php echo _e('Last Posts'); ?></h4>
	</div><!-- #userpage -->
	<div class='userpage_postloop' />
		<?php if (have_posts()) : ?>
	                <?php while (have_posts()) : the_post(); ?>
		                <h5><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?> on <?php the_date('d.m.Y'); ?></a></h5>
        	        <?php endwhile; ?>
	                <?php else: ?>		
				<p><?php _e('Nothing written yet'); ?></p>
        	    	<?php endif; ?>
	</div><!-- #userpage_postloop -->
</div><!-- #content -->

<?php endif; ?>
<?php get_footer(); ?>
